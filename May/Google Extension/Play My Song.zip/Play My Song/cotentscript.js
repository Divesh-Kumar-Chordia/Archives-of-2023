chrome.tabs.executeScript(null, {
    file: "play_song.js"
  });