
var audio = new Audio("https://wynk.in/u/5z8Hy9viQ");
audio.play();

